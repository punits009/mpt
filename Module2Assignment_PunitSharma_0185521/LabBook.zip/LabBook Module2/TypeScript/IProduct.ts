export class IProduct{
    ProId:number;
    ProName:string;
    ProCost:number;
}