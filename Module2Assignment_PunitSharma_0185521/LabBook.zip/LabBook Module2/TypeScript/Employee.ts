import {IEmployee} from './IEmployee';
var empall:IEmployee[]=[{empId:1005,empName:"ABCD",empSalary:1000.11,empStatus:true},
                        {empId:1006,empName:"BCD",empSalary:1000.11,empStatus:true},
                        {empId:1007,empName:"CD",empSalary:1000.11,empStatus:true}];
empall.push({empId:1008,empName:"Punit",empSalary:1000.11,empStatus:true});
empall.splice(1,1);
for(let data of empall)
{
    
console.log(data.empId+" "+data.empName+" "+data.empSalary+" "+data.empStatus);
}