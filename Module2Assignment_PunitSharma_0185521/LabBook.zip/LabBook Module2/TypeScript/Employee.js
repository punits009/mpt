"use strict";
exports.__esModule = true;
var empall = [{ empId: 1005, empName: "ABCD", empSalary: 1000.11, empStatus: true },
    { empId: 1006, empName: "BCD", empSalary: 1000.11, empStatus: true },
    { empId: 1007, empName: "CD", empSalary: 1000.11, empStatus: true }];
empall.push({ empId: 1008, empName: "Punit", empSalary: 1000.11, empStatus: true });
empall.splice(1, 1);
for (var _i = 0, empall_1 = empall; _i < empall_1.length; _i++) {
    var data = empall_1[_i];
    console.log(data.empId + " " + data.empName + " " + data.empSalary + " " + data.empStatus);
}
