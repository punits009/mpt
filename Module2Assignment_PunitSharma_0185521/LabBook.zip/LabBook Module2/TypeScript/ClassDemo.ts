class Employee{
    empid:number;
    empName:string;
    empSalary:number;
    empStatus:boolean;

    printallEmployee():any{
        console.log(this.empid+" "+this.empName+" "+this.empSalary+" "+this.empStatus);
    }
}

var emp=new Employee();// Employee emp=new Employee();
emp.empStatus=true;
emp.empName="Punit";
emp.empId=1001;
emp.empSalary=10002.33;
emp.printallEmployee();
