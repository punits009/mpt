var Employee1 = /** @class */ (function () {
    function Employee1() {
    }
    Employee1.prototype.printallEmployee = function () {
        console.log(this.empId + " " + this.empName + " " + this.empSalary + " " + this.empStatus);
    };
    return Employee1;
}());
var emp = new Employee1(); // Employee emp=new Employee();
emp.empStatus = true;
emp.empName = "Punit";
emp.empId = 1001;
emp.empSalary = 10002.33;
emp.printallEmployee();
