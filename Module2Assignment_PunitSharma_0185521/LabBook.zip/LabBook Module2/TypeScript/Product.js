"use strict";
exports.__esModule = true;
var proall = [{ ProId: 101, ProName: "ABCD", ProCost: 150 },
    { ProId: 102, ProName: "BCD", ProCost: 160 },
    { ProId: 103, ProName: "CD", ProCost: 170 },
    { ProId: 104, ProName: "D", ProCost: 180 }];
proall.push({ ProId: 105, ProName: "DFRE", ProCost: 190 });
for (var _i = 0, proall_1 = proall; _i < proall_1.length; _i++) {
    var data = proall_1[_i];
    console.log(data.ProId + " " + data.ProName + " " + data.ProCost);
}
console.log("Deleting 2 Product");
proall.splice(1, 1);
console.log("After deleting");
for (var _a = 0, proall_2 = proall; _a < proall_2.length; _a++) {
    var data = proall_2[_a];
    console.log(data.ProId + " " + data.ProName + " " + data.ProCost);
}
for (var _b = 0, proall_3 = proall; _b < proall_3.length; _b++) {
    var data = proall_3[_b];
    if (data.ProId == 101) {
        console.log("Product found");
        console.log(data.ProId + " " + data.ProName + " " + data.ProCost);
    }
}
var product;
this.product = this.IProduct.find(function (t) { return t.ProId == 101; });
console.log(this.product);
