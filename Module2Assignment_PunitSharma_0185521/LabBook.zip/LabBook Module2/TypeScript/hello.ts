let empId:number=1001;
let empName:string="ABCD";
let empSalary:number=10002.33;
let empStatus:boolean=true;
console.log(`Employee Name is ${empName} Employee Id is ${empId}`);
console.log("EMployee Salary is" +empSalary);