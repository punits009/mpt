var empId = 1001;
var empName = "ABCD";
var empSalary = 10002.33;
var empStatus = true;
console.log("Employee Name is " + empName + " Employee Id is " + empId);
console.log("EMployee Salary is" + empSalary);
