import {IProduct} from './IProduct';
var proall:IProduct[]=[{ProId:101,ProName:"ABCD",ProCost:150},
                        {ProId:102,ProName:"BCD",ProCost:160},
                        {ProId:103,ProName:"CD",ProCost:170},
                        {ProId:104,ProName:"D",ProCost:180}];

proall.push({ProId:105,ProName:"DFRE",ProCost:190});
for(let data of proall)
{
console.log(data.ProId+" "+data.ProName+" "+data.ProCost);
}
console.log("Deleting 2 Product");
proall.splice(1,1);
console.log("After deleting");
for(let data of proall)
{
console.log(data.ProId+" "+data.ProName+" "+data.ProCost);
}
for(let data of proall)
{
    if(data.ProId==101)
    {
        console.log("Product found");
    console.log(data.ProId+" "+data.ProName+" "+data.ProCost);
}
}
