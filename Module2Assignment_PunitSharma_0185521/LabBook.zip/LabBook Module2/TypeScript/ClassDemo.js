var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.printallEmployee = function () {
        console.log(this.empid + " " + this.empName + " " + this.empSalary + " " + this.empStatus);
    };
    return Employee;
}());
var emp = new Employee(); // Employee emp=new Employee();
emp.empStatus = true;
emp.empName = "Punit";
emp.empid = 1001;
emp.empSalary = 10002.33;
emp.printallEmployee();
