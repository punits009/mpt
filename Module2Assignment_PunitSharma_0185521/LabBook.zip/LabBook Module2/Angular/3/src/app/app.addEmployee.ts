import { Component } from "@angular/core";

@Component({
    selector:'add-emp',
    templateUrl:'addemployee.html'
})


export class AddEmployeeComponent{
    pId:number;
    pName:string;
    pCost:number;
    pOnline:string;
    pon:string;
    empall:any[]=[];
    don:any;
    doff:any;
    pcategory:string;
    pcat:any;
    pava:string="";
    pavarr:any;
    addData()
    {
        this.don=document.getElementById('yes') as HTMLInputElement;
        if(this.don.checked==true)
        {
        this.pon="online";
        } 
        this.doff=document.getElementById('no') as HTMLInputElement;
       
        if(this.doff.checked==true)
        {
            this.pon="offline";
        }
        this.don=document.getElementById('b') as HTMLInputElement;
        if(this.don.checked==true)
        {
            this.pava=this.pava+this.don.value+",";
        }
        this.don=document.getElementById('r') as HTMLInputElement;
        if(this.don.checked==true)
        {
            this.pava=this.pava+this.don.value+",";
        }
        this.don=document.getElementById('d') as HTMLInputElement;
        if(this.don.checked==true)
        {
            this.pava=this.pava+this.don.value+",";
        }
        this.don=document.getElementById('m') as HTMLInputElement;
        if(this.don.checked==true)
        {
            this.pava=this.pava+this.don.value+",";
        }
        
       
        this.empall.push({pId:this.pId,pName:this.pName,pCost:this.pCost,pOnline:this.pon,pcategory:this.pcategory,pava:this.pava});
    }
    
}