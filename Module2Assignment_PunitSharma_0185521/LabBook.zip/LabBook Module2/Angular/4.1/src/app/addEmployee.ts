import {Component} from '@angular/core';

@Component({
    selector:'add-emp',
    templateUrl:'addEmployee.html'
})

export class AddEmployeeComponent{
    arr:any[]=[];   
      
    }