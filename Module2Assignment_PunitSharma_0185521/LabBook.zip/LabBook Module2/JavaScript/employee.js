function addEmployee()
{
   
    var employeeId=document.getElementById('empid').value;
    var employeeName=document.getElementById('empname').value;
    var employeeCourse=document.getElementsByName('course');
    console.log(employeeCourse.length);
    var cou="";
    for(var i=0;i<employeeCourse.length;i++)
    {
        if(employeeCourse[i].checked)
        {
            cou=cou+" "+employeeCourse[i].value;
        }
    }
    var empQualification=document.getElementById('qual').value;
    if(document.getElementById('on').checked)
    {
    var emponline="online";
    } 
    if(document.getElementById('off').checked)
    {
        emponline="offline";
    }
    alert(employeeId+" "+employeeName+" "+cou+" "+empQualification+" "+emponline);
  
    
}